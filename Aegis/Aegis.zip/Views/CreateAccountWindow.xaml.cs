﻿using Aegis.Models;
using Aegis.Security;
using Aegis.Services;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace Aegis.Views
{
    public partial class CreateAccountWindow : Window
    {
        public CreateAccountWindow()
        {
            InitializeComponent();
        }
        
        private void Create_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameBox.Text.Trim();
            var password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username))
                return;

            var accounts = AccountService.LoadAccounts();

            accounts.Add(new AegisAccount
            {
                Username = username,
                DisplayName = username
            });

            AccountService.SaveAccounts(accounts);

            var path = AccountService.GetAccountPath(username);
            Directory.CreateDirectory(path);

            MasterPasswordService.Create(path, password);

            Close();
        }
    }
}
