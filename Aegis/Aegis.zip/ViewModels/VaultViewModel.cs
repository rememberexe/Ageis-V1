﻿using Aegis.Commands;
using Aegis.Models;
using Aegis.Security;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;

namespace Aegis.ViewModels
{
    public class VaultViewModel : ViewModelBase
    {
        private readonly string _username;
        private readonly string _masterPassword;
        public RelayCommand SelectImageCommand { get; private set; }

        public ObservableCollection<VaultEntry> Entries { get; }

        private VaultEntry _selectedEntry;
        public VaultEntry SelectedEntry
        {
            get => _selectedEntry;
            set
            {
                _selectedEntry = value;
                OnPropertyChanged();
                SaveCommand.RaiseCanExecuteChanged();
                DeleteCommand.RaiseCanExecuteChanged();
                SelectImageCommand?.RaiseCanExecuteChanged();
            }

        }
        public void RefreshSelectedEntry()
        {
            OnPropertyChanged(nameof(SelectedEntry));
        }

        private void SelectImage()
        {
            

            var dialog = new OpenFileDialog
            {
                Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp",
                Title = "Select an image"
            };

            if (dialog.ShowDialog() == true)
            {
                // Resimleri app klasörüne kopyalayalım
                string imagesDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Aegis",
                    "Images");

                Directory.CreateDirectory(imagesDir);

                string destPath = Path.Combine(imagesDir, Path.GetFileName(dialog.FileName));
                File.Copy(dialog.FileName, destPath, true);

                SelectedEntry.ImagePath = destPath;
                OnPropertyChanged(nameof(SelectedEntry));
            }
        }

        public RelayCommand AddEntryCommand { get; }

        public RelayCommand SaveCommand { get; }
        public RelayCommand DeleteCommand { get; }
        public static List<VaultEntry> LoadVault(string username, string masterPassword)
        {
            var path = GetVaultPath(username);

            if (!File.Exists(path))
                return new List<VaultEntry>();

            var encrypted = File.ReadAllBytes(path);
            var json = CryptoService.Decrypt(encrypted, masterPassword);

            return JsonSerializer.Deserialize<List<VaultEntry>>(json)
                   ?? new List<VaultEntry>();
        }

        public VaultViewModel(string masterPassword)
        {
            _username = _username
            _masterPassword = masterPassword;

            Entries = new ObservableCollection<VaultEntry>(
                VaultService.LoadVault(masterPassword));

            AddEntryCommand = new RelayCommand(AddEntry);

            SaveCommand = new RelayCommand(Save, () => SelectedEntry != null);
            DeleteCommand = new RelayCommand(Delete, () => SelectedEntry != null);

            SelectImageCommand = new RelayCommand(
                SelectImage,
                () => SelectedEntry != null);
        }


        private void Save()
        {
            VaultService.SaveVault(_masterPassword, Entries.ToList());
        }

        private void Delete()
        {
            if (SelectedEntry == null)
                return;

            Entries.Remove(SelectedEntry);
            SelectedEntry = null;

            VaultService.SaveVault(_masterPassword, Entries.ToList());
        }

        public void AddEntry()
        {
            var entry = new VaultEntry
            {
                DisplayName = "New Entry",
                Username = string.Empty,
                Password = string.Empty,
                Notes = string.Empty,
                ImagePath = null
            };

            Entries.Add(entry);
            SelectedEntry = entry;
        }


    }
}
